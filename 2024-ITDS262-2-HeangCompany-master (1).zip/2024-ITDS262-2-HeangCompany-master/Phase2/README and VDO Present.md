# 2024-ITDS262-2-HeangCompany
# VDO นำเสนอ Project phase2

รายการแก้ไขและคำอธิบายการแก้ไขของสิ่งที่ส่งมอบใน โครงงานระยะที่ 1 
Context Diagram มีการเพิ่ม Data Flow ดังนี้ 

1. ผู้ใช้งาน (User)  

- รับข้อมูล : ข้อมูลการยกเลิกการจอง 

2. ระบบบอกตำแหน่ง (Location API) 

- รับข้อมูล : ข้อมูลตำแหน่ง 

3. ธนาคาร (Bank) 

- รับข้อมูล : ข้อมูลจำนวนเงิน 

4. เจ้าหน้าที่ดูแลสนาม (Court Officer) 

- รับข้อมูล : ข้อมูลสถานะสนาม 

- รับข้อมูล : ข้อมูลสถานะอุปกรณ์

https://drive.google.com/file/d/118xy-gH1ZPJN0rDg-5kIHgkT6U1xh3pe/view?usp=sharing