public class Hi {
  public static void main(String[] args) {
    String name = "Heang";
    System.out.println("Hello " + name);
  }
}
