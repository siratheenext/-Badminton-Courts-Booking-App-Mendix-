public class Sirathee {
    public static void main(String[] args) {
        System.out.println("Hello Sirathee");
    }
}