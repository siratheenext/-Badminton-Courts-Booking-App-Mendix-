public class Thanyarat {
    public static void main(String[] args) {
        System.out.println("Hello Thanyarat");
    }
}