public class <Yourname>Feature {
      public void feature() {
          // this is a new feature
          int x = 0;
          x = x+1;
      }
  }
